'use strict';

const { contextBridge, ipcRenderer } = require('electron');

// Minimal, safe bridge for the bundled quick-chat page only.
// The remote Muse web app itself gets no Node / Electron access.
contextBridge.exposeInMainWorld('museDesktop', {
  openMain: () => ipcRenderer.send('quick-chat:open-main'),
  hideQuickChat: () => ipcRenderer.send('quick-chat:hide'),
  onFocusQuickChat: (callback) => {
    if (typeof callback === 'function') {
      ipcRenderer.on('quick-chat:focus', callback);
    }
  },
});
