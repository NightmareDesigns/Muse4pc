'use strict';

const {
  app,
  BrowserWindow,
  Tray,
  Menu,
  globalShortcut,
  shell,
  Notification,
  nativeImage,
  ipcMain,
} = require('electron');
const path = require('path');
const fs = require('fs');

const MUSE_URL = process.env.MUSE_URL || 'https://muse.ai';
const QUICK_CHAT_SHORTCUT = 'Alt+Space';
const FALLBACK_SHORTCUT = 'Control+Shift+Space';

// Hosts that should stay inside the app. Everything else opens in the
// user's default browser so Muse sign-in flows etc. keep working.
const INTERNAL_HOSTS = new Set([
  'muse.ai',
  'www.muse.ai',
  'agent.meta.ai',
  'ai.meta.com',
  'www.meta.com',
  'accounts.google.com', // Google sign-in for Gmail / Calendar connectors
]);

let mainWindow = null;
let quickWindow = null;
let tray = null;
let isQuitting = false;
let shortcutInUse = null;

// ---------------------------------------------------------------- settings

function settingsPath() {
  return path.join(app.getPath('userData'), 'settings.json');
}

function loadSettings() {
  try {
    return JSON.parse(fs.readFileSync(settingsPath(), 'utf8'));
  } catch {
    return { openAtLogin: false, closeToTray: true, notifiedAboutTray: false };
  }
}

function saveSettings(settings) {
  try {
    fs.mkdirSync(path.dirname(settingsPath()), { recursive: true });
    fs.writeFileSync(settingsPath(), JSON.stringify(settings, null, 2));
  } catch (err) {
    console.error('Could not save settings:', err);
  }
}

let settings = loadSettings();

function applyOpenAtLogin() {
  // setLoginItemSettings only does something meaningful on packaged builds,
  // but calling it in dev is harmless.
  app.setLoginItemSettings({ openAtLogin: Boolean(settings.openAtLogin) });
}

// ---------------------------------------------------------------- windows

function windowStatePath() {
  return path.join(app.getPath('userData'), 'window-state.json');
}

function loadWindowBounds() {
  try {
    const b = JSON.parse(fs.readFileSync(windowStatePath(), 'utf8'));
    if (Number.isFinite(b.width) && Number.isFinite(b.height)) return b;
  } catch {}
  return { width: 1180, height: 820 };
}

function saveWindowBounds() {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.isMinimized()) return;
  try {
    fs.writeFileSync(windowStatePath(), JSON.stringify(mainWindow.getBounds()));
  } catch {}
}

function iconPath() {
  return path.join(__dirname, '..', 'assets', 'icon.png');
}

function createMainWindow() {
  const bounds = loadWindowBounds();
  mainWindow = new BrowserWindow({
    ...bounds,
    minWidth: 760,
    minHeight: 560,
    show: false,
    autoHideMenuBar: true,
    title: 'Muse',
    icon: iconPath(),
    backgroundColor: '#111111',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.loadURL(MUSE_URL);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('resize', saveWindowBounds);
  mainWindow.on('move', saveWindowBounds);

  mainWindow.on('close', (event) => {
    if (!isQuitting && settings.closeToTray && tray) {
      event.preventDefault();
      mainWindow.hide();
      if (!settings.notifiedAboutTray) {
        settings.notifiedAboutTray = true;
        saveSettings(settings);
        if (Notification.isSupported()) {
          new Notification({
            title: 'Muse is still running',
            body: 'Muse was minimized to the system tray. Use the tray icon to reopen or quit.',
          }).show();
        }
      }
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  wireNavigation(mainWindow);
  return mainWindow;
}

function createQuickWindow() {
  quickWindow = new BrowserWindow({
    width: 430,
    height: 600,
    show: false,
    frame: false,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    title: 'Muse Quick Chat',
    icon: iconPath(),
    backgroundColor: '#111111',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  quickWindow.loadFile(path.join(__dirname, 'quick-chat.html'));
  quickWindow.on('blur', () => quickWindow && quickWindow.hide());
  quickWindow.on('closed', () => {
    quickWindow = null;
  });
  return quickWindow;
}

function toggleQuickChat() {
  if (!quickWindow) createQuickWindow();
  if (quickWindow.isVisible()) {
    quickWindow.hide();
  } else {
    quickWindow.show();
    quickWindow.focus();
    quickWindow.webContents.send('quick-chat:focus');
  }
}

function showMainWindow() {
  if (!mainWindow) createMainWindow();
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

// Keep Muse / Meta / Google sign-in inside the app; open everything else
// in the default browser.
function wireNavigation(win) {
  const handle = (event, url) => {
    let host = '';
    try {
      host = new URL(url).hostname;
    } catch {
      return;
    }
    if (!INTERNAL_HOSTS.has(host)) {
      event.preventDefault();
      shell.openExternal(url);
    }
  };
  win.webContents.on('will-navigate', handle);
  win.webContents.setWindowOpenHandler(({ url }) => {
    let host = '';
    try {
      host = new URL(url).hostname;
    } catch {}
    if (INTERNAL_HOSTS.has(host)) return { action: 'allow' };
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ---------------------------------------------------------------- tray / menu

function buildTray() {
  const image = nativeImage
    .createFromPath(iconPath())
    .resize({ width: 20, height: 20 });
  tray = new Tray(image);
  tray.setToolTip('Muse');

  const refreshMenu = () => {
    const menu = Menu.buildFromTemplate([
      { label: 'Open Muse', click: showMainWindow },
      {
        label: `Quick Chat  (${shortcutInUse || QUICK_CHAT_SHORTCUT})`,
        click: toggleQuickChat,
      },
      { type: 'separator' },
      {
        label: 'Start on login',
        type: 'checkbox',
        checked: Boolean(settings.openAtLogin),
        click: (item) => {
          settings.openAtLogin = item.checked;
          saveSettings(settings);
          applyOpenAtLogin();
          refreshMenu();
        },
      },
      {
        label: 'Close button minimizes to tray',
        type: 'checkbox',
        checked: Boolean(settings.closeToTray),
        click: (item) => {
          settings.closeToTray = item.checked;
          saveSettings(settings);
          refreshMenu();
        },
      },
      { type: 'separator' },
      {
        label: 'Quit Muse',
        click: () => {
          isQuitting = true;
          app.quit();
        },
      },
    ]);
    tray.setContextMenu(menu);
  };

  refreshMenu();
  tray.on('click', showMainWindow);
  tray.on('double-click', showMainWindow);
}

function buildAppMenu() {
  const template = [
    {
      label: 'Muse',
      submenu: [
        { label: 'Open Muse', accelerator: 'Control+Shift+O', click: showMainWindow },
        { label: 'Quick Chat', click: toggleQuickChat },
        { type: 'separator' },
        {
          label: 'Quit',
          accelerator: 'Control+Q',
          click: () => {
            isQuitting = true;
            app.quit();
          },
        },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { role: 'togglefullscreen' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ---------------------------------------------------------------- IPC

ipcMain.on('quick-chat:open-main', () => {
  if (quickWindow) quickWindow.hide();
  showMainWindow();
});
ipcMain.on('quick-chat:hide', () => {
  if (quickWindow) quickWindow.hide();
});

// ---------------------------------------------------------------- lifecycle

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', showMainWindow);

  app.whenReady().then(() => {
    applyOpenAtLogin();
    buildAppMenu();
    createMainWindow();
    createQuickWindow();
    buildTray();

    shortcutInUse = QUICK_CHAT_SHORTCUT;
    if (!globalShortcut.register(QUICK_CHAT_SHORTCUT, toggleQuickChat)) {
      shortcutInUse = FALLBACK_SHORTCUT;
      if (!globalShortcut.register(FALLBACK_SHORTCUT, toggleQuickChat)) {
        shortcutInUse = null;
        console.warn('Could not register a quick-chat shortcut.');
      }
    }
    buildTray(); // rebuild so the menu shows the shortcut that actually registered

    app.on('activate', showMainWindow);
  });

  app.on('before-quit', () => {
    isQuitting = true;
  });

  app.on('will-quit', () => {
    globalShortcut.unregisterAll();
  });

  // On Windows the app lives in the tray, so don't quit when windows close.
  app.on('window-all-closed', () => {
    if (process.platform !== 'win32' && !settings.closeToTray) app.quit();
  });
}
